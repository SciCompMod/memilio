+++
title = "`basic_outcome() = delete`"
description = "The default constructor (disabled)."
categories = ["constructors", "implicit-constructors", "default-constructors"]
weight = 100
+++

The default constructor for basic outcome is always disabled.
