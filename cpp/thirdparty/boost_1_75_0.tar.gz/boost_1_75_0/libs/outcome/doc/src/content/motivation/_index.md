+++
title = "Motivation"
weight = 8
+++

This section describes techniques currently used to report and handle failures
in functions, it also shows why these techniques might be insufficient.

If you just want to learn how to use Outcome library go straight to [Tutorial
section]({{% relref "/tutorial" %}}).

{{% notice note %}}
Motivation section of this documentation is not complete yet.
{{% /notice %}}


{{% children description="true" depth="1" %}}
