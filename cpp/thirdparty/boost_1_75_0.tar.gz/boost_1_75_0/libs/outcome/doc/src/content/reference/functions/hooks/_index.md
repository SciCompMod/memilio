+++
title = "Hooks"
description = "Functions used to hook into the functionality of `basic_result` and `basic_outcome`."
weight = 30
+++

{{% children description="true" depth="2" %}}
