+++
title = "Essential"
description = "The absolute minimum that you need to know to get started with Outcome immediately."
weight = 10
+++

{{% children description="true" depth="2" %}}
