+++
title = "Iostream"
description = "Functions used to print, serialise and deserialise `basic_result` and `basic_outcome`."
weight = 35
+++

{{% children description="true" depth="2" %}}
