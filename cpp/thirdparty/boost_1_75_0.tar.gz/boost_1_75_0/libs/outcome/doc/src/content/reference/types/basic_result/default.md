+++
title = "`basic_result() = delete`"
description = "The default constructor (disabled)."
categories = ["constructors", "implicit-constructors", "default-constructors"]
weight = 100
+++

The default constructor for basic result is always disabled.
