Note that the html documentation is generated from the Markdown in src by
a Travis job on standalone https://github.com/ned14/outcome.

Please send pull requests fixing documentation issues to
https://github.com/ned14/outcome/pulls.
